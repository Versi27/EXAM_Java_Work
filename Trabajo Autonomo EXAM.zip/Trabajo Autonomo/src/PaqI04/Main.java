package PaqI04;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Container c = new Container();
        //Scanner scan = new Scanner(System.in);
        //int w = scan.nextInt();

        c.compareWeights();
        /*c.setWeight(58);
        c.setWeight2(69);
        c.setPriority(2);*/
        System.out.println(c.toString());


        Hub h = new Hub();
        /*c.setPriority(1);
        h.apilar(c);
        System.out.println(h.getV()[0].length);
        System.out.println(h.getV()[8][0].country);
        System.out.println(h);

        //h.contC();

         */

    }
}
