package PaqI04;
// --> NAME: Versabia Mª Moraga López

import java.util.Scanner;

public class Container {
    //ATTRIBUTES:
    int id, weight, weight2 ,priority;
    String country, description, emisor, receptor;
    public boolean inspected;


    //CONSTRUCTORS:
    public Container() {

    }
    public Container(int id, int weight, int weight2, String country, int priority, String description, String emisor, String receptor, boolean inspected){
        this();
        if (id < 0) id = -id;
        else this.id = id;
        this.setWeight(weight);
        this.setWeight2(weight2);
        this.setCountry(country);
        this.setPriority(priority);
        this.setDescription(description);
        this.setEmisor(emisor);
        this.setReceptor(receptor);
        this.inspected = inspected;
    }


    //GETTERS & SETTERS:
    public int getId() {
        return id;
    }
    public void setId(int id) {
        if (id < 0) this.id = -id;
        else this.id = id;
    }

    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        if(country != null) this.country = country;
    }

    public int getWeight() {
        return weight;
    }
    public void setWeight(int weight) {
        if (weight < 0) this.weight = -weight;
        else this.weight = weight;
    }

    public int getWeight2() {
        return weight2;
    }
    public void setWeight2(int weight2) {
        if (weight2 < 0) this.weight2 = -weight2;
        else this.weight2 = weight2;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        if (description != null) this.description = description;
    }

    public int getPriority() {
        return priority;
    }
    public void setPriority(int priority) {
        if (priority >= 1 && priority <= 3) {
            this.priority = priority;
        }
    }

    public String getEmisor() {
        return emisor;
    }
    public void setEmisor(String emisor) {
        if (emisor != null) this.emisor = emisor;
    }

    public String getReceptor() {
        return receptor;
    }
    public void setReceptor(String receptor) {
        if (receptor != null) this.receptor = receptor;
    }

    public boolean isInspected() {
        return inspected;
    }

    //METHODS:
    public void compareWeights(){
        /*Scanner scan = new Scanner(System.in);
        int w = scan.nextInt();
        int w2 = scan.nextInt();*/

        if(weight2 <= weight) System.out.println(weight2);
        else System.out.println(weight);

    }



    //TO STRING:
    public String toStringW(){
        String s = new String();
        if (weight2 <= weight){
            s += "The valid weight is: " + weight2 + " tons\n";
        }
        else{
            s += "The valid weight is: " + weight + " tons\n";
        }return s;
    }
    public String toString(){
        String s = new String();
        s += "---------------------CONTAINER INFORMATION----------------------\n";

        if (weight2 <= weight){
            s += "Id: " + this.id + "\n";
            s += "Weight: " + weight2 + " tons\n";
            s += "Company that sends the container: " + this.emisor + "\n";
            s += "Is inspected?: ";
            s += "Inspected";
        }
        else {
            s += "Id: " + this.id + "\n";
            s += "Weight: " + weight + " tons\n";
            s += "Country of origin: " + this.country + "\n";
            if (priority == 1) s += "Priority: 1 \n";
            else if (priority == 2) s += "Priority: 2 \n";
            else if (priority == 3) s += "Priority: 3 \n";
            else s += "Error in the priority \n";
            s += "Description: " + this.description + "\n";
            s += "Company that sends the container: " + this.emisor + "\n";
            s += "Company that receives the container: " + this.receptor + "\n";
            s += "Is inspected?: ";
            if (isInspected()) s += "Inspected";
            else s += "Not inspected" + "\n";
        }
        return s;
    }

}
